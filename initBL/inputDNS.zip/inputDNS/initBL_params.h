INIT  = "initBoundaryLayer"
! ------------ use equation of state ------------------ 
USE_EOS  = "IG"
! ------------ set non-dimensional free-stream values for computation ------------------ 
Re =1239.718636
Pra =0.750000
Ec =5.000000e-02
Ma =3.535534e-01
Tinf =300.000000
Pref =5.714286
ig_gam =1.400000
eos_Rgas =5.714286
eos_dof =9.000000
! ------------ set wall BC for computation ------------------ 
wall_bc  = "isoth"
Twall =1.021630
! ------------ set viscosity and conductivity ------------------ 
USE_VISC  = "PowerLaw"
Stref =273.000000
Muinf =1.841774e-05
Muref =1.716000e-05
Smuref =111.000000
Kinf =2.586640e-02
Kref =2.410000e-02
Skref =194.000000
! -------------- mesh parameters ------------------------------- 
ReBlasiusStart =250.000000
zStartBL =50.414665
zEndBL =98.812744
len_z =48.398079
ReTau =43.947152
yPlus =2.275460e-02
! --------------------------------------- 
